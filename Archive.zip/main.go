package testzip
import "fmt"

function Print() {
	fmt.Println("ALL GOODD")
}
