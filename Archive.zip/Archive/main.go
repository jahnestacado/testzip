package testzip

import "fmt"

func Print() {
	fmt.Println("ALL GOODD")
}
